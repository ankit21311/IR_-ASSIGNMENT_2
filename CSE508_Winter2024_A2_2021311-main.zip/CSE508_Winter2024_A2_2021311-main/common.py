import pandas as pd
import numpy as np
import os
dataset_path = 'A2_Data.csv'
df = pd.read_csv(dataset_path)
output_dir = 'CSE508_Winter2024_A2_2021311-main'